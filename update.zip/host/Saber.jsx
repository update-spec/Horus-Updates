(function applyHorusV13Dynamic() {
    var proj = app.project;
    var comp = proj.activeItem;

    if (!(comp instanceof CompItem) || comp.selectedLayers.length !== 1) {
        alert("HÔRUS: يرجى اختيار لير واحد فقط.");
        return;
    }

    app.beginUndoGroup("HÔRUS Pre-Comp & Saber Dynamic");

    try {
        var originalLayer = comp.selectedLayers[0];
        var topLayer = originalLayer.duplicate();
        
        // 1. عمل Pre-compose للصورة بنفس أبعادها
        var layerIndex = originalLayer.index;
        var preCompName = originalLayer.name + "_HÔRUS_PC";
        comp.layers.precompose([layerIndex], preCompName, true); 
        
        var targetLayer = comp.layer(layerIndex);
        targetLayer.selected = true;
        topLayer.selected = false;

        // 2. تنفيذ Auto-trace
        app.executeCommand(app.findMenuCommandId("Auto-trace..."));

        // 3. تحديد مسار الـ Preset ديناميكياً (يعمل على أي جهاز)
        // Folder.userData تعادل C:\Users\Username\AppData\Roaming
        var roamingPath = Folder.userData.fsName;
        var presetPath = roamingPath + "/Adobe/CEP/extensions/com.horus.v13/host/Horus_Saber.ffx";
        var presetFile = new File(presetPath);

        var finalTraceLayer = comp.selectedLayers[0];

        if (finalTraceLayer && finalTraceLayer !== topLayer) {
            if (presetFile.exists) {
                finalTraceLayer.applyPreset(presetFile);
            } else {
                alert("HÔRUS: لم يتم العثور على الملف في المسار الديناميكي:\n" + presetPath);
            }

            // 4. الترتيب النهائي
            topLayer.moveToBeginning();
            finalTraceLayer.moveAfter(topLayer);
        }

    } catch (err) {
        alert("HÔRUS Critical Error: " + err.message);
    }

    app.endUndoGroup();
})();