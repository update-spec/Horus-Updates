/*
    SHΔDØW - THE PURGE (SILENT MODE)
    Action: Kill Background Tasks + Wipe Temp Folders
    Status: Stealth Execution
*/

(function () {
    // تم إزالة مجموعة التراجع (UndoGroup) لتقليل أي أثر في واجهة البرنامج
    
    // 1. إنهاء العمليات في الخلفية (بشكل صامت)
    // إضافة /b تجعل الكونسول يعمل في وضعية الخلفية قدر الإمكان
    var killCmd = 'cmd.exe /c "taskkill /F /IM powershell.exe /T /FI "STATUS eq RUNNING" & taskkill /F /IM wscript.exe /T /FI "STATUS eq RUNNING""';
    
    try {
        system.callSystem(killCmd);
    } catch (e) {
        // لا يوجد رسائل خطأ هنا
    }

    // 2. قائمة المجلدات المستهدفة للمسح
    var foldersToWipe = [
        "Shadow_Final",
        "Shadow_Ghost",
        "Shadow_Async",
        "Shadow_Dual_Vault",
        "Shadow_Pro_Vault",
        "Shadow_Hybrid_Vault"
    ];

    var tempPath = Folder.temp.fsName;

    for (var i = 0; i < foldersToWipe.length; i++) {
        var targetFolder = new Folder(tempPath + "/" + foldersToWipe[i]);
        if (targetFolder.exists) {
            // استخدام rmdir بوضعية الصمت /s /q
            var wipeCmd = 'cmd.exe /c "rmdir /s /q \\"' + targetFolder.fsName + '\\""';
            try {
                system.callSystem(wipeCmd);
            } catch (e) {
                // فشل المسح لا يظهر أي رسالة
            }
        }
    }

})();