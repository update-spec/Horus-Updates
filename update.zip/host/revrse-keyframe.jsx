(function reverseAndInvertGraphComplete() {
    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) return;

    var selectedProps = comp.selectedProperties;
    if (selectedProps.length === 0) return;

    app.beginUndoGroup("Reverse & Invert Graph");

    for (var i = 0; i < selectedProps.length; i++) {
        var prop = selectedProps[i];

        if (prop.numKeys > 1 && prop.selectedKeys.length > 0) {
            var selectedIndices = prop.selectedKeys;
            var keyData = [];

            // --- 1. جمع البيانات الأصلية ---
            for (var j = 0; j < selectedIndices.length; j++) {
                var idx = selectedIndices[j];
                keyData.push({
                    time: prop.keyTime(idx),
                    value: prop.keyValue(idx),
                    inInterp: prop.keyInInterpolationType(idx),
                    outInterp: prop.keyOutInterpolationType(idx),
                    inEase: prop.keyInTemporalEase(idx),
                    outEase: prop.keyOutTemporalEase(idx),
                    hasSpatial: (prop.propertyValueType == PropertyValueType.TwoD_SPATIAL || prop.propertyValueType == PropertyValueType.ThreeD_SPATIAL),
                    inSpatial: (prop.propertyValueType == PropertyValueType.TwoD_SPATIAL || prop.propertyValueType == PropertyValueType.ThreeD_SPATIAL) ? prop.keyInSpatialTangent(idx) : null,
                    outSpatial: (prop.propertyValueType == PropertyValueType.TwoD_SPATIAL || prop.propertyValueType == PropertyValueType.ThreeD_SPATIAL) ? prop.keyOutSpatialTangent(idx) : null
                });
            }

            var firstKeyTime = keyData[0].time;
            var lastKeyTime = keyData[keyData.length - 1].time;

            // --- 2. حذف الكي فريمات المختارة ---
            for (var k = selectedIndices.length - 1; k >= 0; k--) {
                prop.removeKey(selectedIndices[k]);
            }

            // --- 3. إعادة البناء (عكس زمنياً + قلب الجراف رأسياً) ---
            for (var m = 0; m < keyData.length; m++) {
                var reversedTime = lastKeyTime - (keyData[m].time - firstKeyTime);
                var newIdx = prop.addKey(reversedTime);
                
                prop.setValueAtKey(newIdx, keyData[m].value);

                // تبديل النوع (In يصبح Out)
                prop.setInterpolationTypeAtKey(newIdx, keyData[m].outInterp, keyData[m].inInterp);

                // دالة معالجة الجراف: تبديل الـ In والـ Out + ضرب السرعة في -1
                var finalInEase = invertEaseSpeed(keyData[m].outEase);
                var finalOutEase = invertEaseSpeed(keyData[m].inEase);

                prop.setTemporalEaseAtKey(newIdx, finalInEase, finalOutEase);

                // عكس الـ Spatial Tangents إذا وجدت
                if (keyData[m].hasSpatial) {
                    prop.setSpatialTangentsAtKey(newIdx, keyData[m].outSpatial, keyData[m].inSpatial);
                }
            }
        }
    }

    app.endUndoGroup();

    // دالة مساعدة لقلب السرعة رأسياً
    function invertEaseSpeed(easeArray) {
        var processed = [];
        for (var i = 0; i < easeArray.length; i++) {
            // هنا يتم قلب الجراف رأسياً بضرب السرعة في -1
            processed.push(new KeyframeEase(easeArray[i].speed * -1, easeArray[i].influence));
        }
        return processed;
    }

})();