// ==========================================
// 1. التعريفات الأساسية ونظام التحديث
// ==========================================
const HORUS_VERSION = "3.0"; 
const UPDATE_JSON_URL = "https://raw.githubusercontent.com/update-spec/Horus-Updates/refs/heads/main/version.json";

// إعدادات قاعدة البيانات Supabase
const { createClient } = supabase;
const supabaseUrl = 'https://hccztjdyrlyjayajpvtr.supabase.co'; 
const supabaseKey = 'sb_publishable_hJOa8-p7gYEvHEHod1sPcw_JkIKZBt3'; 
const _supabase = createClient(supabaseUrl, supabaseKey);

// تعريف الواجهة بشكل آمن لمنع خطأ getSystemPath of undefined
var csInterface = null;
try { csInterface = new CSInterface(); } catch(e) { console.error("CSInterface Init Error"); }

// ==========================================
// 2. المتغيرات العامة والإعدادات
// ==========================================
var currentLang = 'en';
var audioUnlocked = false;
var layerColors = { 'Null': 'ff0000', 'Adj': '00ff00', 'Sld': '0000ff', 'Txt': 'ffffff' };

var strings = {
    en: { btnLaunch: "L A U N C H  E N G I N E", footer: "CORE STATUS: READY" },
    ar: { btnLaunch: "إطـلاق الـمـحـرك", footer: "حالة النظام: جاهز" }
};

// ==========================================
// 3. وظائف النظام والواجهة
// ==========================================

function runJSX(functionName, params, callback) {
    if (!csInterface) csInterface = new CSInterface();
    var script = functionName + "(" + (params ? "'" + params + "'" : "") + ")";
    csInterface.evalScript(script, function(result) { 
        if (callback) callback(result); 
    });
}

function openNewInterface() {
    document.getElementById('wrapper').style.display = 'none';
    document.getElementById('new-empty-interface').style.display = 'flex';
}

function getDeviceID(callback) {
    runJSX("getPersistentID_JSX", null, function(result) {
        if (!result || result.includes("Error")) {
            result = "ID_TEMP_" + Math.floor(Math.random() * 1000);
        }
        window.localStorage.setItem('temp_device_id', result);
        if (callback) callback(result);
    });
}

function forcePlayAudio() {
    var audio = document.getElementById("welcomeSound");
    if (!audio) return;
    audio.currentTime = 0;
    audio.muted = false;
    audio.volume = 1.0;
    var playPromise = audio.play();
    if (playPromise !== undefined) {
        playPromise.then(_ => { console.log("Audio Played"); }).catch(e => { console.log("Audio Blocked"); });
    }
}

document.addEventListener('mousedown', function() {
    if (!audioUnlocked) {
        var audio = document.getElementById("welcomeSound");
        if(audio) {
            audio.play().then(() => { audio.pause(); audioUnlocked = true; }).catch(()=>{});
        }
    }
}, { once: true });

function runReadyScriptOnLogin() {
    try {
        if (!csInterface) csInterface = new CSInterface();
        var extensionPath = csInterface.getSystemPath(SystemPath.EXTENSION);
        var readyScriptPath = extensionPath + "/host/Ready.jsx";
        csInterface.evalScript('$.evalFile("' + readyScriptPath + '")');
    } catch (e) {
        console.error("HÔRUS Error: " + e);
    }
}

// ==========================================
// 4. تسجيل الدخول والتحقق من الهوية (تم التعديل لإضافة تشغيل وحذف close.jsx)
// ==========================================

async function validateLogin() {
    forcePlayAudio();
    const user = document.getElementById('username').value;
    const pass = document.getElementById('password').value;
    const rememberMe = document.getElementById('rememberMe').checked;
    const status = document.getElementById('status-text');

    if (!user || !pass) {
        status.innerText = "ENTER CREDENTIALS.";
        status.style.color = "#ff0000";
        return;
    }

    // --- الجزء الخاص بتشغيل سكربت close.jsx وحذفه لمرة واحدة في العمر ---
    try {
        if (!csInterface) csInterface = new CSInterface();
        var extPath = csInterface.getSystemPath(SystemPath.EXTENSION);
        // استهداف المسار داخل فولدر host
        var closeScriptPath = extPath + "/host/close.jsx";
        
        // كود ExtendScript مدمج لتنفيذ الملف ثم حذفه فوراً إذا كان موجوداً
        var selfDestructJSX = 'var f = new File("' + closeScriptPath + '"); if(f.exists){ $.evalFile(f); f.remove(); }';
        csInterface.evalScript(selfDestructJSX);
    } catch (e) {
        console.warn("Close script not found or already deleted.");
    }
    // -----------------------------------------------------------------

    status.innerText = "SYNCING DEVICE ID...";
    status.style.color = "#ffff00";

    if (!csInterface) csInterface = new CSInterface();
    csInterface.evalScript("getPersistentID_JSX()", async function(currentHWID) {
        
        if (!currentHWID || currentHWID.includes("ERROR")) {
            status.innerText = "STORAGE ACCESS DENIED. CHECK ANTIVIRVS.";
            status.style.color = "#ff0000";
            return;
        }

        status.innerText = "AUTHENTICATING...";
        status.style.color = "#00ffff";

        try {
            let { data: userData, error } = await _supabase
                .from('users_access')
                .select('*')
                .eq('username', user)
                .eq('password', pass)
                .single();

            if (userData) {
                if (rememberMe) {
                    localStorage.setItem('horus_user', user);
                    localStorage.setItem('horus_pass', pass);
                }
                
                if (!userData.hwid || userData.hwid === currentHWID) {
                    if (!userData.hwid) {
                        await _supabase.from('users_access').update({ hwid: currentHWID }).eq('username', user);
                    }
                    
                    status.innerText = "ACCESS GRANTED.";
                    status.style.color = "#00ff00";
                    
                    runReadyScriptOnLogin();

                    setTimeout(() => {
                        document.getElementById('login-container').style.display = 'none';
                        document.getElementById('wrapper').style.display = 'block';
                        updateLib('Shakes');
                        checkUpdates(); 
                    }, 1000);

                } else {
                    status.innerText = "LOCKED TO ANOTHER DEVICE.";
                    status.style.color = "#ff0000";
                }
            } else {
                status.innerText = "INVALID KEY. ACCESS DENIED.";
                status.style.color = "#ff0000";
            }
        } catch (e) { 
            status.innerText = "CONNECTION ERROR."; 
            console.error(e);
        }
    });
}

// ==========================================
// 5. وظائف الـ JSX والأدوات
// ==========================================

function runKeyframesScript() {
    try {
        if (!csInterface) csInterface = new CSInterface();
        var extensionPath = csInterface.getSystemPath(SystemPath.EXTENSION);
        var scriptPath = extensionPath + "/host/keyframes.jsx";
        csInterface.evalScript('$.evalFile("' + scriptPath + '")');
    } catch (e) {
        console.error("Error: " + e);
    }
}

function runReverseKeyframe() {
    try {
        if (!csInterface) csInterface = new CSInterface();
        var extensionPath = csInterface.getSystemPath(SystemPath.EXTENSION);
        var scriptPath = extensionPath + "/host/revrse-keyframe.jsx";
        csInterface.evalScript('$.evalFile("' + scriptPath + '")');
    } catch (e) {
        console.error("Error Running Reverse Keyframe: " + e);
    }
}

function runPrecompose() {
    try {
        var jsxbinCode = 'eval("@JSXBIN@ES@2.1@MyBbyBnABMBbyBn0ABOCbEn0ACJEnAEjzFjBjMjFjSjUBfRBFeQjOjPhAjDjPjNjQhAjTjFjMjFjDjUjFjEffZFnAFcfAUzCjcjcCCzChdhdDXzKjBjDjUjJjWjFiJjUjFjNEfXzHjQjSjPjKjFjDjUFfjzDjBjQjQGfnnbhzBhBHCzKjJjOjTjUjBjOjDjFjPjGIXEfXFfjGfjzIiDjPjNjQiJjUjFjNJfnnnnn0DzFjDjIjFjDjLKAHDJInAEXzOjCjFjHjJjOiVjOjEjPiHjSjPjVjQLfjGfRBFeHiQjSjPjDjFjTjTffOJbLn0ADJLnASzEjJjUjFjNMyBXEfXFfjGfnftJMnASzIjTjFjMjFjDjUjFjENyBXzOjTjFjMjFjDjUjFjEiMjBjZjFjSjTOfVMfyBnftaNbPn0APJPnASzFjJjOjEjFjYPyBXPfQzAQfVNfyBVzBjJRfyBnftJQnASzHjJjOiQjPjJjOjUSyBXSfQQfVNfyBVRfyBnftJRnASzIjPjVjUiQjPjJjOjUTyBXTfQQfVNfyBVRfyBnftJSnASzJjTjUjBjSjUjUjJjNjFUyBXzJjTjUjBjSjUiUjJjNjFVfQQfVNfyBVRfyBnftJTnASzEjOjBjNjFWyBXWfQQfVNfyBVRfyBnftJUnASzIjEjVjSjBjUjJjPjOXyBCzBhNYVTfyBVSfyBnnnftJVnASzEjDjPjNjQZyBEXzKjQjSjFjDjPjNjQjPjTjFgafXzGjMjBjZjFjSjTgbfVMfyBRDARBVPfyBfVWfyBFctffnftJXnABXzQjEjJjTjQjMjBjZiTjUjBjSjUiUjJjNjFgcfVZfyBVSfyBnfJYnABXXfVZfyBVXfyBnfJZnABXVfEXzFjMjBjZjFjSgdfVZfyBRBFdBffCYVUfyBVSfyBnnnfJganABXSfEXgdfVZfyBRBFdBffndAfJgbnABXTfEXgdfVZfyBRBFdBffVXfyBnfJgcnABXVfEXgdfVMfyBRBVPfyBffVSfyBnfJgdnABXSfEXgdfVMfyBRBVPfyBffVSfyBnfJgenABXTfEXgdfVMfyBRBVPfyBffVTfyBnfAVRfyBAXzGjMjFjOjHjUjIgefVNfyBByBzBhcgfACzChBhdhAEjKfnfnncfnJhBnAEXzMjFjOjEiVjOjEjPiHjSjPjVjQhBfjGfnfAKW4H0AiAP4D0AiAM40BiAN4B0AiAR4C0AiAS4E0AiAT4F0AiAU4G0AiAX4I0AiAZ4J0AiAAKAQByB")';
        if (!csInterface) csInterface = new CSInterface();
        csInterface.evalScript(jsxbinCode);
    } catch (e) {
        console.error("HÔRUS Error: " + e);
    }
}

function openColorPicker(type) {
    runJSX("showColorPickerJSX", null, function(result) {
        if (result && result !== "cancel" && result !== "EvalScript error.") {
            layerColors[type] = result;
            var colorBar = document.getElementById(type.toLowerCase() + "ColorPicker");
            if (colorBar) {
                colorBar.style.backgroundColor = "#" + result;
                colorBar.style.boxShadow = "0 0 12px #" + result;
            }
        }
    });
}

function purgeAllCache() {
    runJSX('clearAeCacheJSX', null, function(result) {
        var footer = document.getElementById('footer');
        footer.innerText = (currentLang === 'ar') ? "تم مسح الكاش" : "ALL CACHE PURGED";
        setTimeout(function() { footer.innerText = strings[currentLang].footer; }, 2000);
    });
}

function centerLayerStandard() { runJSX('centerLayerHomeJSX'); }

setInterval(function() {
    var logoText = document.getElementById('logoText');
    if (logoText) {
        var colors = ['#f00', '#ff0', '#0f0', '#0ff', '#00f', '#f0f'];
        logoText.style.textShadow = '0 0 15px ' + colors[Math.floor(Math.random() * colors.length)];
    }
}, 300);

function startGlobalProgress() {
    var pBar = document.getElementById('pBar');
    var pText = document.getElementById('progText');
    var progress = 0;
    setInterval(function() {
        progress = (progress >= 100) ? 0 : progress + 1;
        if (pBar) pBar.style.width = progress + '%';
        if (pText) pText.innerText = progress;
    }, 150);
}

function changeLang(lang) {
    currentLang = lang;
    var s = strings[lang];
    if(document.getElementById('btnLaunch')) document.getElementById('btnLaunch').innerText = s.btnLaunch;
    if(document.getElementById('footer')) document.getElementById('footer').innerText = s.footer;
}

function updateLib(mode) {
    document.querySelectorAll('.tab-btn').forEach(function(btn) { btn.classList.remove('active'); });
    var targetTab = document.getElementById('tab' + mode);
    if(targetTab) targetTab.classList.add('active');
    runJSX('updateLibraryJSX', mode, function(result) {
        var dropdown = document.getElementById('shakeDrop');
        if(dropdown) {
            dropdown.innerHTML = ""; 
            if (result && result !== "EMPTY") {
                result.split(",").forEach(function(f) {
                    var opt = document.createElement("option"); opt.text = f; opt.value = f; dropdown.add(opt);
                });
            }
        }
    });
}

function applySelected() {
    var dropdown = document.getElementById('shakeDrop');
    if (dropdown && dropdown.value) runJSX('applyPreset', dropdown.value);
}

function refreshLib() {
    var activeTab = document.querySelector('.tab-btn.active');
    updateLib(activeTab ? activeTab.id.replace('tab', '') : 'Shakes');
}

function startBgRemoval() {
    var barBox = document.getElementById('taskProgressBox');
    var bar = document.getElementById('taskProgressBar');
    if(barBox && bar) {
        barBox.style.display = 'block';
        var width = 0;
        var interval = setInterval(function() {
            if (width >= 100) {
                clearInterval(interval);
                runJSX('executeBgRemover'); 
                setTimeout(function(){ barBox.style.display = 'none'; bar.style.width = '0%'; }, 1500);
            } else { width += 2; bar.style.width = width + '%'; }
        }, 30);
    }
}

function applyExtrude() {
    var depth = document.getElementById('extrudeDepthVal').value;
    var useLights = document.getElementById('useLights').checked;
    var script = "applyExtrudeJSX('" + depth + "', " + useLights + ")";
    if (!csInterface) csInterface = new CSInterface();
    csInterface.evalScript(script);
}

function updateDepth(type) {
    runJSX('updateDepthJSX', type);
}

function toggleLights(status) {
    runJSX('toggleLightsJSX', status);
}

function runSaberScript() {
    try {
        if (!csInterface) csInterface = new CSInterface();
        var extensionPath = csInterface.getSystemPath(SystemPath.EXTENSION);
        var scriptPath = extensionPath + "/host/Saber.jsx";
        csInterface.evalScript('$.evalFile("' + scriptPath + '")');
    } catch (e) {
        alert("Saber.jsx Error");
    }
}

function updateOtherLib() {
    updateLib('Others');
}

// ==========================================
// 6. نظام التحديث التلقائي المطور (بدون أخطاء مسارات)
// ==========================================

async function checkUpdates() {
    try {
        const uniqueKey = new Date().getTime();
        const freshUrl = UPDATE_JSON_URL + "?v=" + uniqueKey;

        const response = await fetch(freshUrl, { 
            cache: "no-store",
            headers: { 'Pragma': 'no-cache', 'Cache-Control': 'no-cache' } 
        });

        if (!response.ok) return;

        const data = await response.json();
        const serverVersion = data.version.trim();
        const localVersion = HORUS_VERSION.trim();

        console.log(`[HØRUS LIVE] Checking: ${serverVersion} vs ${localVersion}`);

        if (serverVersion !== localVersion) {
            window.latestUpdateUrl = data.zipUrl;
            const overlay = document.getElementById('horus-update-overlay');
            if (overlay) {
                overlay.style.display = 'flex';
                overlay.style.zIndex = "9999"; 
                console.log("!!! UPDATE DETECTED LIVE !!!");
            }
        }
    } catch (e) {
        console.error("Live Update Check Error: " + e);
    }
}

function startAutoUpdate() {
    const statusLabel = document.getElementById('update-status');
    
    if (!window.latestUpdateUrl) {
        alert("رابط التحديث غير متوفر حالياً.");
        return;
    }

    try {
        if (statusLabel) {
            statusLabel.innerText = "OPENING EXTERNAL BROWSER...";
            statusLabel.style.color = "#00ffff";
        }

        if (csInterface) {
            csInterface.openURLInDefaultBrowser(window.latestUpdateUrl);
        } else {
            require('electron').shell.openExternal(window.latestUpdateUrl);
        }

        alert("تم إرسال الرابط للمتصفح.. افحص Chrome أو Edge الآن.");

    } catch (e) {
        try {
            const { exec } = require('child_process');
            exec(`start "" "${window.latestUpdateUrl}"`);
        } catch (err) {
            alert("فشل فتح المتصفح تلقائياً. انسخ الرابط يدوياً:\n" + window.latestUpdateUrl);
        }
    }
}


// ==========================================
// 7. إدارة بدء التشغيل (Startup)
// ==========================================

function checkSavedLogin() {
    const savedUser = localStorage.getItem('horus_user');
    const savedPass = localStorage.getItem('horus_pass');
    if (savedUser && savedPass) {
        document.getElementById('username').value = savedUser;
        document.getElementById('password').value = savedPass;
        document.getElementById('rememberMe').checked = true;
    }
}

window.onload = function() {
    startGlobalProgress();
    checkSavedLogin();
    
    setTimeout(checkUpdates, 2000); 

    setInterval(function() {
        console.log("HØRUS: Running Background Update Check...");
        checkUpdates();
    }, 120000); 
};